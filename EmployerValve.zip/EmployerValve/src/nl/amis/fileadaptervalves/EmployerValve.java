package nl.amis.fileadaptervalves;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.logging.Logger;

import javax.xml.namespace.QName;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.util.StreamReaderDelegate;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXResult;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;

import oracle.tip.pc.services.pipeline.AbstractValve;
import oracle.tip.pc.services.pipeline.InputStreamContext;
import oracle.tip.pc.services.pipeline.PipelineException;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLFilterImpl;
import org.xml.sax.helpers.XMLReaderFactory;


public class EmployerValve extends AbstractValve {

  private static final String USE_STAX_PROPERTY_NAME = "useStAX";
  private static final String TMP_FILE_PREFIX = "fileAdapterValve";
  private static final String TMP_FILE_SUFFIX = ".tmp";
  private static final String TAG_Employee = "Employee";
  private static final String TAG_Employer = "Employer";

  private File file = null;
  private final Logger logger = Logger.getLogger(this.getClass().getName());

  public EmployerValve() {
    super();
  }

  public InputStreamContext execute(InputStreamContext inputStreamContext) throws PipelineException, IOException {
    // Get the input stream that is passed to the Valve

    logger.finest("================START FileAdapterAbzendValve================");
    String s = (String)getPipeline().getPipelineContext().getProperty(USE_STAX_PROPERTY_NAME);
    boolean useStAX = !"false".equalsIgnoreCase(s); //defaults to true
    logger.finest("useStAX=" + useStAX);

    //modify xml being read
    InputStream originalInputStream = inputStreamContext.getInputStream();
    InputStream newInputStream = transform(originalInputStream, useStAX);
    inputStreamContext.closeStream();
    inputStreamContext.setInputStream(newInputStream);
    logger.finest("================END FileAdapterAbzendValve================");
    return inputStreamContext;
  }

  private InputStream transform(final InputStream input, final boolean useStax) throws PipelineException, IOException {
    final InputStream is;
    final OutputStream out;

    file = File.createTempFile(TMP_FILE_PREFIX, TMP_FILE_SUFFIX);
    out = new FileOutputStream(file);
    logger.finest("tempfile=" + file.getAbsoluteFile());
    try {
      final Source src;
      final Result res;
      if (useStax){

        final XMLStreamReader xmlStreamReader = XMLInputFactory.newFactory().createXMLStreamReader(input, "UTF-8");
        final StreamReaderDelegate streamReaderDelegate = new StreamReaderDelegate(xmlStreamReader){
          private boolean startEmployer = false;
          private boolean endingEmployer = false;

          @Override
          public int next() throws XMLStreamException{
            int event;
            if (endingEmployer){
              event = START_ELEMENT; //end of ending werkgever node, continue with starting werknemer node
                                     //in which the parent already is.
              logger.finest("StAX: end faking ending element " + TAG_Employer + ", so now returning start element");
            }
            else{
              event = getParent().next();
            }
            endingEmployer = false;
            if (!startEmployer && event == START_ELEMENT){
              if (TAG_Employer.equals(getParent().getLocalName())){
                startEmployer = true;
                logger.finest("StAX: starting element " + TAG_Employer + " found");
              }
            }
            else if (startEmployer && event == START_ELEMENT){
              if (TAG_Employee.equals(getParent().getLocalName())){
                startEmployer = false;
                event = END_ELEMENT;
                endingEmployer = true; //we're going into the state of ending the werkgever node
                logger.finest("StAX: starting element " + TAG_Employee + " found, start faking end element " + TAG_Employer);
              }
            }
            else if (event == END_ELEMENT){
              if (TAG_Employer.equals(getParent().getLocalName())){
                event = getParent().next(); //goto next node, so this node is skipped.
                logger.finest("StAX: skip ending element " + TAG_Employer);
              }
            }
            return event;
          }

          @Override
          public String getLocalName(){
            if (endingEmployer){ //we're in the state of ending the werkgever node (parent is in ending werknemer node)
              return TAG_Employer;
            }
            else{
              return getParent().getLocalName();
            }
          }

          @Override
          public QName getName(){
            QName qName = getParent().getName();//we're in the state of ending the werkgever node (parent is in ending werknemer node)
            if (endingEmployer){
             qName = new QName(qName.getNamespaceURI(), TAG_Employer, qName.getPrefix());
            }
            return qName;
          }

          @Override
          public int getEventType(){
            if (endingEmployer){//we're in the state of ending the werkgever node (parent is in ending werknemer node)
             return END_ELEMENT;
            }
            else{
              return getParent().getEventType();
            }
          }

        };

        src = new StAXSource(streamReaderDelegate);
        final XMLStreamWriter xmlStreamWriter = XMLOutputFactory.newFactory().createXMLStreamWriter(out, "UTF-8");
        res = new StAXResult(xmlStreamWriter);
      }
      else{
        final XMLReader xr = new XMLFilterImpl(XMLReaderFactory.createXMLReader()) {
          private boolean found = false;

          @Override
          public void startElement(final String uri, final String localName, final String qName, final Attributes atts) throws SAXException {
            if (!(found) && TAG_Employee.equals(qName)) {
              found = true;
              logger.finest("SAX: Insert closing tag " + TAG_Employer);
              super.endElement(uri, TAG_Employer, TAG_Employer);
            }
            super.startElement(uri, localName, qName, atts);
          }

          @Override
          public void endElement(final String uri, final String localName, final String qName) throws SAXException {
            if (found && TAG_Employer.equals(qName)) {
              //System.out.println("uri:" + uri + " localName:" + localName + " qName:" + qName);
              //delete this closing tag
              found = false;
              logger.finest("SAX: Skip closing tag " + TAG_Employer);
            } else {
              super.endElement(uri, localName, qName);
            }
          }
        };
        src = new SAXSource(xr, new InputSource(input));
        res = new StreamResult(out);
      }
      TransformerFactory.newInstance().newTransformer().transform(src, res);
      logger.finest("Transformation done!");

     } catch (SAXException e) {
      e.printStackTrace();
      } catch (XMLStreamException e) {
       e.printStackTrace();
    } catch (TransformerConfigurationException e) {
      e.printStackTrace();
    } catch (TransformerException e) {
      e.printStackTrace();
    }
    out.flush();
    out.close();
    is = new FileInputStream(file);
    return is;
  }

  public void test(final boolean useStAX ) throws IOException, ParserConfigurationException, SAXException,
                            PipelineException, InterruptedException {
    long start = System.currentTimeMillis();

    File file = new File("Employers.xml");
    if (!file.exists()){
      System.out.print("File does not exist!");
    }
    else{
      FileInputStream in = new FileInputStream(file);
      InputStream result = transform(in, useStAX);
      ByteArrayOutputStream bos = new ByteArrayOutputStream();
      byte[] buffer = new byte[2048];
      int bytesRead;
      while ((bytesRead = result.read(buffer)) != -1) {
        bos.write(buffer, 0, bytesRead);
      }
      String s = new String(bos.toByteArray(), "UTF-8");
      in.close();
      result.close();
      System.out.println(">>" + s + "<<");

      System.out.println("duration: " + (System.currentTimeMillis() - start) + "ms");
    }
  }


  public void finalize(InputStreamContext inputStreamContext) {
    try {
      cleanup();
    } catch (PipelineException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void cleanup() throws PipelineException, IOException {
    if (file != null && file.exists()){
      file.delete();
      file = null;
    }
  }

  public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException,
                                                PipelineException, InterruptedException {

    EmployerValve valve = new EmployerValve();
    valve.test(false);
    valve.finalize(null);
    valve.test(true);
    valve.finalize(null);
  }

}
